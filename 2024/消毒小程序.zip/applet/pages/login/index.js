var util = require('../../utils/util.js');
var api = require('../../utils/api.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    number: '',
    password: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },
  /**
   * 用户登录
   */
  userLogin() {
    if (this.data.number == '') {
      util.showErrorToast('请输入账号')
      return;
    }
    if (this.data.password == '') {
      util.showErrorToast('请输入密码')
      return;
    }
    let param = {
      "number": this.data.number.trim(),
      "password": this.data.password.trim()
    }
    util.request(api.userLogin, param).then(function (res) {
      if (res.obj != null) {
        //将token保存到缓存中
        wx.setStorageSync('token', res.obj.userData.token)
        wx.switchTab({
          url: '/pages/index/index'
        })
      } else {
        util.showErrorToast(res.message)
      }
    });
  }
})