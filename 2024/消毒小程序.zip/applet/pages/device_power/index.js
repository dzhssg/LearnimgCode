var util = require('../../utils/util.js');
var api = require('../../utils/api.js');
Page({
  /**
   * 页面的初始数据
   */
  data: {
    deviceList: [], //设备列表
    total: 0, //总记录数
    pageNumber: 1, //第几页，默认为第1页
    rowsCount: 2, //每页显示数据
    noMoreData: true, //没有更多数据
    noMore: false, //显示是否有更多了
    device: { //当前修改的设备对象
      id: '',
      name: '',
      code: '',
      startPower: '',
      endPower: ''
    },
    startPower: '', //最小功率
    endPower: '', //最大功率
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.getDevice()
  },
  //获取设备信息
  getDevice: function () {
    let that = this;
    let param = {
      "columns": "id,code,number,name,status,startPower,endPower",
      "pageNumber": this.data.pageNumber - 1,
      "rowsCount": this.data.rowsCount,
      "name": "",
      "number": ""
    }
    util.request(api.getDevice, param).then(function (res) {
      that.setData({
        deviceList: that.data.deviceList.concat(res.obj.rows),
        total: res.obj.total
      })
    });
  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {
    //判断是否还有数据进行加载
    if (this.data.total > this.data.pageNumber * this.data.rowsCount) {
      this.setData({
        pageNumber: this.data.pageNumber + 1 //页码数加1
      });
      this.getDevice();
    }
  },
  //修改设备信息（功率）
  editDevice(e) {
    // let item = e.target.dataset.item
    // if (item.startPower > item.endPower) {
    //   util.showErrorToast('最大功率应比最小功率大')
    //   return
    // }
    util.request(api.editDevice, this.data.device).then(function (res) {
      util.showErrorToast(res.message)
    });
  },
  // 绑定最小功率
  bindStartPower(e) {
    let item =  e.target.dataset.item
    item.startPower = e.detail.value
    this.setData({
      device: item
    });
    console.log(this.data.device)
  },
  // 绑定最大功率
  bindEndPower(e) {
    let item =  e.target.dataset.item
    item.endPower = e.detail.value.replace(/\D/g, '')
    this.setData({
      device: item
    });
    console.log(this.data.device)
  },
  //验证只能输入数字
  inputDigit: function (e) {
    let pwd = e.detail.value
    console.log(e.detail.value)
    let result = pwd.replace(/[^\d]/g, '')
  },
  // 电话输入
  mobileInput(e) {
    let value = e.detail.value.replace(/\D/g, '')
    console.log(value)
    this.setData({
      startPower: 123
    })
  },
})