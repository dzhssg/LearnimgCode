var util = require('../../utils/util.js');
var api = require('../../utils/api.js');

// TODO 订单显示数量在图标上

const app = getApp()

Page({
  data: {
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    status: {}, //订单状态
    money: '0', //;余额
  },
  goProfile: function (e) {
    let res = util.loginNow();
    if (res == true) {
      wx.navigateTo({
        url: '/pages/ucenter/settings/index',
      });
    }
  },
  onLoad: function (options) {},
  onShow: function () {
    let userInfo = wx.getStorageSync('userInfo');
    if (userInfo == '') {
      this.setData({
        hasUserInfo: 0,
      });
    } else {
      this.setData({
        hasUserInfo: 1,
      });
    }
    this.setData({
      userInfo: userInfo,
    });
  },

  onPullDownRefresh: function () {},

  //前往个人信息页面
  gotoPerson: function () {
    wx.navigateTo({
      url: '/pages/person/index',
    });
  },
  //前往关于我们页面
  gotoAbout: function () {
    wx.navigateTo({
      url: '/pages/about/index',
    });
  },
  //前往密码修改页面
  gotoPasswordEdit: function () {
    wx.navigateTo({
      url: '/pages/password/index',
    });
  },

  //安全退出
  gotoQuit: function () {
    wx.showModal({
      title: '提示',
      content: '您确认退出小程序吗？',
      success(res) {
        if (res.confirm) {
          //清空缓存
          wx.clearStorageSync()
          //跳转到登录页面
          wx.redirectTo({
            url: '/pages/login/index',
          })
        }
      }
    })
  },
})