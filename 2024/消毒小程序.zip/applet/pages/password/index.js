var util = require('../../utils/util.js');
var api = require('../../utils/api.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    oldPassword: '', //旧密码
    newPassword: '', //新密码
    confirmPassword: '', //确认密码
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },
  //密码修改
  editPassword() {
    // setpassword(User user),user参数的密码password为新密码；edit(User user)
    if (this.data.oldPassword == '') {
      util.showErrorToast('请输入旧密码')
      return;
    }
    if (this.data.newPassword == '') {
      util.showErrorToast('请输入新密码')
      return;
    }
    if (this.data.confirmPassword == '') {
      util.showErrorToast('请输入确认密码')
      return;
    }
    if (this.data.newPassword != this.data.confirmPassword) {
      util.showErrorToast('新密码与确认不一致，请重新输入')
      return;
    }
    let param={
      id:'1',
      oldPassword:this.data.oldPassword,
      password:this.data.newPassword
    }
    util.request(api.editPassword, param).then(function (res) {
      console.log(res)
      if (res.obj != null) {
        
      } else {
        util.showErrorToast(res.message)
      }
    });
  },
})