var util = require('../../utils/util.js');
var api = require('../../utils/api.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    device:{
      id:'',//设备id
      name:'',//设备名称
      factory:'',//设备生产厂家
      supplier:'',//设备供应商
      functions:'',//设备功能
      type:''//设备类型
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },
  //修改设备信息（功率）
  editDevice() {
    util.request(api.editDevice, this.data.device).then(function (res) {
      util.showErrorToast(res.message)
    });
  },
  //绑定设备名称
  bindName(e){
    let data=this.data.device
    data.name=e.detail.value
    this.setData({
      device:data
    })
  },
  //绑定设备名称
  bindFactory(e){
    let data=this.data.device
    data.factory=e.detail.value
    this.setData({
      device:data
    })
  },
  //绑定设备名称
  bindSupplier(e){
    let data=this.data.device
    data.supplier=e.detail.value
    this.setData({
      device:data
    })
  },
  //绑定设备名称
  bindFunctions(e){
    let data=this.data.device
    data.functions=e.detail.value
    this.setData({
      device:data
    })
  },
  //绑定设备名称
  bindType(e){
    let data=this.data.device
    data.type=e.detail.value
    this.setData({
      device:data
    })
  },
})