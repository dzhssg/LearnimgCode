var util = require('../../utils/util.js');
var api = require('../../utils/api.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list: [], //设备列表
    total: 0, //总记录数
    pageNumber: 1, //第几页，默认为第1页
    rowsCount: 2, //每页显示数据
    noMoreData: true, //没有更多数据
    noMore: false, //显示是否有更多了
    statusOption: [ //状态选项
      {
        value: '工作',
        name: '工作',
        checked: 'true'
      },
      {
        value: '待机',
        name: '待机'
      },
      {
        value: '离线',
        name: '离线'
      }
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.getData()
  },
  //获取设备信息
  getData: function () {
    let that = this;
    let param = {
      "columns": "id,code,number,name,status",
      "pageNumber": this.data.pageNumber - 1,
      "rowsCount": this.data.rowsCount,
      "name": "",
      "number": ""
    }
    util.request(api.getDevice, param).then(function (res) {
      that.setData({
        list: that.data.list.concat(res.obj.rows),
        total: res.obj.total
      })
    });
  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {
    //判断是否还有数据进行加载
    if (this.data.total > this.data.pageNumber * this.data.rowsCount) {
      this.setData({
        pageNumber: this.data.pageNumber + 1 //页码数加1
      });
      this.getData();
    }
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },
  //状态切换
  changeStatus: function (e) {
    let that=this
    let param = {
      "id":  e.target.dataset.id,
      "status": e.detail.value
    }
    util.request(api.changeDeviceStatus, param).then(function (res) {
      if (res.message == "状态变更成功！") {
        util.showErrorToast(res.message)
      }
    });
  }
})