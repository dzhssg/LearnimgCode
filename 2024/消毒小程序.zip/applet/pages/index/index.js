
// index.js
// 获取应用实例
const app = getApp()

Page({
  data: {
    banner: [
      { image: '/images/banner/1.jpg' },
      { image: '/images/banner/2.jpg' },
      { image: '/images/banner/3.jpg' },
    ],
    announcementText: '这里是最新的公告信息，请大家注意查看！', // 公告栏文本
    // 其他数据...
    announcementMarquee: 0, // 公告栏滚动位置
  },
  onLoad() {
    // 页面加载时的逻辑...
    this.startScrollingAnnouncement();
  },
  startScrollingAnnouncement() {
    const query = wx.createSelectorQuery();
    query.select('.announcement-text').boundingClientRect();
    query.select('.announcement-bar').boundingClientRect();
    query.exec((res) => {
      if (res[0] && res[1]) {
        const textWidth = res[0].width;
        const barWidth = res[1].width;
        const duration = textWidth * 20; // 滚动速度，可根据需要调整
  
        this.animation = wx.createAnimation({
          duration: 0,
          timingFunction: 'linear',
        });
  
        const animate = () => {
          // 从初始位置开始
          this.animation.translateX(barWidth).step({duration: 0});
          this.setData({ animationData: this.animation.export() });
  
          // 滚动到结束位置
          this.animation.translateX(-textWidth).step({duration: duration});
          this.setData({ animationData: this.animation.export() });
  
          // 动画结束后重新开始
          setTimeout(animate, duration);
        };
        animate();
      }
    });
  },
  // 事件处理函数

  bindViewTap() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },

  onLoad() {
    if (wx.getUserProfile) {
      this.setData({
        canIUseGetUserProfile: true
      })
    }
    //缓存中没有token，说明未登录，跳转到登录页面
    if(wx.getStorageSync('token').length==0 || wx.getStorageSync('token')==''){
      wx.redirectTo({
        url: '/pages/login/index',
      })
    }
  },
  getUserProfile(e) {
    // 推荐使用wx.getUserProfile获取用户信息，开发者每次通过该接口获取用户个人信息均需用户确认，开发者妥善保管用户快速填写的头像昵称，避免重复弹窗
    wx.getUserProfile({
      desc: '展示用户信息', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
      success: (res) => {
        console.log(res)
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    })
  },
  getUserInfo(e) {
    // 不推荐使用getUserInfo获取用户信息，预计自2021年4月13日起，getUserInfo将不再弹出弹窗，并直接返回匿名的用户个人信息
    console.log(e)
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  }
})



