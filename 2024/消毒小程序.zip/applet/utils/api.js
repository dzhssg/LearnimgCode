const ApiRootUrl = 'http://115.159.64.129:8201/';//请求地址根目录
module.exports = {
    // 首页
    userLogin:ApiRootUrl + 'user/login',//用户登录
    editPassword:ApiRootUrl + 'user/changePwd',//用户修改密码

    getDevice:ApiRootUrl + 'device/findByPage',//获取设备信息
    getDeviceById:ApiRootUrl+'device/getMe',
    changeDeviceStatus:ApiRootUrl + 'device/changeStatus',//更改设备状态
    editDevice:ApiRootUrl + 'device/edit',//修改设备

    getRunRecord:ApiRootUrl + 'runrecord/findByPage',//获取设备运行记录
    getDeviceRunRecordDetail:ApiRootUrl+'runrecord/getME',
    
};