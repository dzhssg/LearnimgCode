const formatTime = date => {
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()
  const hour = date.getHours()
  const minute = date.getMinutes()
  const second = date.getSeconds()

  return `${[year, month, day].map(formatNumber).join('/')} ${[hour, minute, second].map(formatNumber).join(':')}`
}

const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : `0${n}`
}
/**
 * 封封微信的的request
 */
function request(url, data = {}, method = "POST") {
  wx.showNavigationBarLoading(); //显示顶部导航栏加载进度条
  return new Promise(function (resolve, reject) {
    wx.request({
      url: url,
      data: data,
      method: method,
      header: {
        'Content-Type': 'application/json',
        "token": wx.getStorageSync('token'),
        "Appid": "8d99b7b2e42569c06dbf89746cba8d92",
        "Appkey": "8d99b7b2e42569c06dbf89746cba8d92"
      },
      success: function (res) {
        if (res.statusCode == 200) {
          resolve(res.data);
        } else {
          reject(res.errMsg);
        }

      },
      fail: function (err) {
        reject(err)
      },
      complete: function () {
        wx.hideNavigationBarLoading(); //隐藏顶部导航栏加载进度条
      }
    })
  });
}

function showErrorToast(msg) {
  wx.showToast({
    title: msg,
    icon: 'none',
    mask: true, //是否显示透明蒙层，防止触摸穿透，默认：false 
  })
}

function showSuccessToast(msg) {
  wx.showToast({
    title: msg,
    icon: 'success',
    mask: true, //是否显示透明蒙层，防止触摸穿透，默认：false 
  })
}

function showModal(msg) {
  wx.showModal({
    content: msg,
    confirmText: "确定",
    showCancel: false
  })
}
// input正则校验只能输入为数字和小数点位数限制
function checkDigit(e) {
  console.log(456)
  // let val = e.target.value.replace(/(^\s*)|(\s*$)/g, "")
  // if (!val) {
  //   return ''
  // }
  // var reg = /[^\d.]/g
  // // 只能是数字和小数点，不能是其他输入
  // val = val.replace(reg, "")
  // // // 保证第一位只能是数字，不能是点
  // val = val.replace(/^\./g, "");
  // // // 小数只能出现1位
  // val = val.replace(".", "$#$").replace(/\./g, "").replace("$#$", ".");
  // // // 小数点后面保留2位
  // val = val.replace(/^(\-)*(\d+)\.(\d\d).*$/, '$1$2.$3');
  // console.log(val);
  // return val
}
module.exports = {
  formatTime,
  request,
  showErrorToast,
  showSuccessToast,
  showModal,
  checkDigit
}